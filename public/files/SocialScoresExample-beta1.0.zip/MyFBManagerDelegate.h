//
//  MyFBManagerDelegate.h
//  
//
//  Created by lsease on 10-06-18.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//


#import "FBDialog.h"
@protocol MyFBManagerDelegate<NSObject,NSCoding>

@optional
///callback for get friends method. Returns array of dictionaries.
-(void) gotFriendResults:(NSArray*)friends;

///callback for a successful login
-(void) didFinishLogin;

///callback for successful logout
-(void) didFinishLogout;

///callback for a successful FB posting 
-(void) dialogDidSucceed:(FBDialog*)dialog;
@end
