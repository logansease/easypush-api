//
//  SocialScoresManager.h
//  
//
//  Created by logan sease on 12-05-01.
//  Copyright (c) 2012 Logan Sease. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ScoresViewController.h"

//TODO edit these config variables


#define kPostLink           @"http://unfedundead.com"           //the link for fb share posts
#define kPostImage          @"http://logansease.com/zombieicon.png"  //image for fb posts
#define kAppName            @"test app!"        //display name for fb share posts
#define kSocialAppId        @"test ID"       //app id from your social scores app
#define kSocialAppSecret    @"test secret"  //secret key from social scores app


@protocol SocialScoresManagerDelegate <NSObject>
@optional

/** This method will pass the score load result to your class. The results will be in the form of:
 * A dictionary containing "fb_scores" and "scores", where the latter is overall.
 * These dictionaries will be arrays where each item is a dictionary with one key, "score".
 * This dictionary contains a key for "score" and for "name". Both are strings
 */
-(void)scoreLoadDidFinish:(NSDictionary*)scores;
@end


@interface SocialScoresManager : NSObject
{
    //accessory controller to show scores
    ScoresViewController * scoresController;
}

+(id) sharedManager;
+ (BOOL)connected;
-(void)showTopScoresForLevel:(NSString*)levelId withOptions:(NSDictionary*)options;
-(void)loadTopScoresForLevel:(NSString*)levelId withOptions:(NSDictionary*)options;
-(BOOL)saveScore:(int)score forLevel:(NSString*)levelId;
-(void) setEnabled:(BOOL)isEnabled;
-(BOOL) isEnabled;
-(void)prepareForFbUser;

@property(nonatomic,retain) ScoresViewController * scoresController;

@end



