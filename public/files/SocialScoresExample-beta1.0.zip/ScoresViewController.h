//
//  ScoresViewController.h
//  Feedin Zombies
//
//  Created by logan sease on 5/3/12.
//  Copyright (c) 2012 Logan Sease. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScoresViewController : UITableViewController
{
    //all scores
    NSArray * overallScores;
    
    //scores used to display. Don't set this
    NSArray * scores;
    
    //facebook friends scores
    NSArray * fbScores;
    
    //players score
    int playerScore;
    
    //used internally if no fbscores are set
    BOOL noFb;
    
    //segment to change between overall and fb scores
    UISegmentedControl * typeSegment;
    
    //the level ID
    NSString *levelId;
}

@property BOOL noFb;
@property int playerScore;
@property(nonatomic,retain) NSString * levelId;
@property(nonatomic,retain)  UISegmentedControl * typeSegment;
@property(nonatomic,retain) NSArray * fbScores;
@property(nonatomic,retain) NSArray * overallScores;

@end
