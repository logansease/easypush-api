//
//  FBFriendSelectDelegate.h
//  MovieQuotes
//
//  Created by lsease on 10-06-18.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//


@protocol  FBFriendSelectDelegate<NSObject,NSCoding>
@optional
-(void) didSelectFriend:(NSDictionary*)friend;

@end
