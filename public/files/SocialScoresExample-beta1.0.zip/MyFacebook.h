
#import "Facebook.h"


@interface Facebook (socialscores)

- (void)authorizeInApp:(NSArray *)permissions;
- (void)authorizeWithFBAppAuth:(BOOL)tryFBAppAuth
                    safariAuth:(BOOL)trySafariAuth ;
- (NSString *)getOwnBaseUrl;
@end
