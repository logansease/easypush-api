//
//  MyFBManager.h
//
//  Created by lsease on 10-06-16.
//  Copyright 2010 iParty Mobile. All rights reserved.
//  This Manager Class is used to manage a facebook connect object.

#import <Foundation/Foundation.h>
#import "Facebook.h"
#import "MyFacebook.h"
#import "MyFBManagerDelegate.h"
#import "SocialScoresConfig.h"

#define kFbPermissions [NSArray arrayWithObjects:@"publish_stream",@"email",nil]


@interface MyFBManager : NSObject<FBSessionDelegate,FBDialogDelegate,FBRequestDelegate,UIWebViewDelegate> {
	Facebook * facebook;
	id<MyFBManagerDelegate> delegate;
	int dialogState;
	FBLoginDialog * loginDialog;
    
    NSString * email;
    NSString * name;
    int facebookId;

}

+ (id)sharedManager;

-(void)getFriendList;
-(void) showLogin;
-(void) postStoryWithAttachment:(NSMutableDictionary*)params toFriend:(NSString*)friendId;
-(void) autoPostStoryWithAttachment:(NSMutableDictionary*)params toFriend:(NSString*)friendId;
-(void) getPermission;

@property(nonatomic,retain) NSString * email;
@property(nonatomic,retain) NSString * name;
@property int facebookId;
@property(nonatomic,retain) FBLoginDialog * loginDialog;
@property(nonatomic,retain) id<MyFBManagerDelegate> delegate;
@property(nonatomic,retain) Facebook* facebook;
@end
