//
//  ViewController.h
//  apiexample
//
//  Created by logan sease on 5/8/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


-(IBAction)settingsPressed;
-(IBAction)showScoresPressed;

@end
