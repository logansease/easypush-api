//
//  ScoresViewController.m
//  Feedin Zombies
//
//  Created by logan sease on 5/3/12.
//  Copyright (c) 2012 Jeremie Weldin. All rights reserved.
//

#import "ScoresViewController.h"
#import "SocialScoresManager.h"
#import <objc/runtime.h>
#import "MyFBManager.h"

@implementation ScoresViewController
@synthesize playerScore;
@synthesize fbScores;
@synthesize levelId;
@synthesize overallScores;
@synthesize noFb;
@synthesize typeSegment;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.tableView.backgroundColor = [UIColor colorWithWhite:1.0f alpha:0.7f];

    typeSegment = [[UISegmentedControl alloc] initWithItems:[NSArray arrayWithObjects:@"Friends",@"Overall", nil]];
    typeSegment.selectedSegmentIndex = 0;
	typeSegment.autoresizingMask = UIViewAutoresizingFlexibleWidth;
	typeSegment.segmentedControlStyle = UISegmentedControlStyleBar;
	typeSegment.frame = CGRectMake(55, 5, 211, 25);
	[typeSegment addTarget:self action:@selector(segmentPress:) forControlEvents:UIControlEventValueChanged];
    
    

    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if(noFb)
    {
            typeSegment.selectedSegmentIndex = 1;
            [typeSegment setEnabled:NO forSegmentAtIndex:0];
            
        
        scores = overallScores;
    }
    else
    {
        scores=fbScores;
        typeSegment.selectedSegmentIndex = 0;
        [typeSegment setEnabled:YES forSegmentAtIndex:0];
    }
    [self.tableView reloadData];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    // Return the number of rows in the section.
    return [scores count];
}


- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    [[cell textLabel] setBackgroundColor:[UIColor clearColor]];
    [[cell detailTextLabel] setBackgroundColor:[UIColor clearColor]];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier] autorelease];
        cell.textLabel.backgroundColor = [UIColor clearColor];
        cell.detailTextLabel.backgroundColor = [UIColor clearColor];
        cell.backgroundColor = [UIColor clearColor];
        cell.backgroundView = nil;
        cell.contentView.backgroundColor = [UIColor clearColor];
        
    }
    
    NSDictionary * scoreDict = [scores objectAtIndex:indexPath.row];
    NSDictionary * score = [scoreDict objectForKey:@"score"];
    // Configure the cell...
    
    
    cell.textLabel.text = [NSString stringWithFormat:@"%i.  %@",indexPath.row + 1, [score objectForKey:@"name"]];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@",[score objectForKey:@"score"]];
    
    return cell;
}



- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 70;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    
    UIView * header = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 70)]autorelease];
    //if(self.interfaceOrientation == UIInterfaceOrientationPortrait)
    //{
     //   header.frame = CGRectMake(0, 0, 320, 50);
    //}
    

        UIButton * infoButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        //if(self.interfaceOrientation == UIInterfaceOrientationPortrait)
        //{
            infoButton.frame = CGRectMake(5, 5, 25, 25);
        //}
    [infoButton setImage:[UIImage imageNamed:@"closebutton.png"] forState:UIControlStateNormal];
        [infoButton addTarget:self action:@selector(closePressed) forControlEvents:UIControlEventTouchUpInside];
        [header addSubview:infoButton];
    
    UILabel * label = [[[UILabel alloc] initWithFrame:CGRectMake(35, 5, 280, 30)] autorelease];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont fontWithName:@"Arial" size:10.0f];
    label.textColor = [UIColor blackColor];
    label.text = @"Social Leader Boards powered by SocialScoresApi.com";
    label.numberOfLines = 1;
    [header addSubview:label];
    
    UILabel * scoreLabel = [[[UILabel alloc] initWithFrame:CGRectMake(5, 35, 310, 30)] autorelease];
    scoreLabel.backgroundColor = [UIColor clearColor];
    scoreLabel.font = [UIFont boldSystemFontOfSize:[UIFont systemFontSize] + 5];
    scoreLabel.textColor = [UIColor blackColor];
    scoreLabel.textAlignment= UITextAlignmentCenter;
    scoreLabel.text = [NSString stringWithFormat:@"Your Score:  %i",playerScore];
    scoreLabel.numberOfLines = 1;
    [header addSubview:scoreLabel];
    if(playerScore <= 0)
    {
        scoreLabel.text = @"";
    }
    
    return header;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 60;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIView * footer = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 60)]autorelease];
    
    UIButton * infoButton = [UIButton buttonWithType:UIButtonTypeCustom];
    infoButton.frame = CGRectMake(90, 35, 150, 25);
    [infoButton setImage:[UIImage imageNamed:@"fb_share.png"] forState:UIControlStateNormal];
    [infoButton addTarget:self action:@selector(sharePressed) forControlEvents:UIControlEventTouchUpInside];
    [footer addSubview:infoButton];
    
    [footer addSubview:typeSegment];

    
    return footer;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}


#pragma action methods

-(IBAction)segmentPress:(id)sender
{
    UISegmentedControl * seg = (UISegmentedControl*)sender;
    if(seg.selectedSegmentIndex == 1)
    {
        scores  = overallScores;
    }
    else
    {
        scores = fbScores;
    }
    [self.tableView reloadData];
}

-(void)sharePressed
{
    NSMutableDictionary * attachment = [NSMutableDictionary dictionary];
    [attachment setValue:[NSString stringWithFormat: @"Check out this social scoreboard for: %@", kAppName] forKey:@"name"];
    [attachment setValue:[NSString stringWithFormat:@"Level: %@",levelId] forKey:@"caption"];
    NSMutableString * scoresStr = [NSMutableString string];
    
    int i = 1;
    for(NSDictionary * scoreDict in scores)
    {
        NSDictionary * score = [scoreDict objectForKey:@"score"];
        [scoresStr appendFormat:@"<center> %i.  %@  --  %i</center>",i,[score objectForKey:@"name"],[[score objectForKey:@"score"] intValue]];
        i++;
        if(i >10)
            break;
    }
    [attachment setValue:scoresStr forKey:@"description"];
    [attachment setValue:kPostLink forKey:@"link"];
    [attachment setValue:kPostImage forKey:@"picture"];
    
    MyFBManager *fb= [MyFBManager sharedManager];
    [fb postStoryWithAttachment:attachment toFriend:nil];
    
}

-(void)closePressed
{
    [self dismissModalViewControllerAnimated:YES];
}

-(void)dealloc
{
    [super dealloc];
    [scores release];
    [levelId release];
    [fbScores release];
    [typeSegment release];
    [overallScores release];
}

@end
