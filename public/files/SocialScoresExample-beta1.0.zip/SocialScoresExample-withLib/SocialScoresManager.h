//
//  SocialScoresManager.h
//  Feedin Zombies
//
//  Created by logan sease on 12-05-01.
//  Copyright (c) 2012 Logan Sease. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ScoresViewController.h"

//TODO edit these config variables


#define kPostLink           @"http://unfedundead.com"           //the link for fb share posts
#define kPostImage          @"http://logansease.com/zombieicon.png"  //image for fb posts
#define kAppName            @"test app!"        //display name for fb share posts
#define kSocialAppId        @"test ID"       //app id from your social scores app
#define kSocialAppSecret    @"test secret"  //secret key from social scores app




@protocol SocialScoresManagerDelegate <NSObject>
@optional
-(void)scoreLoadDidFinish:(NSDictionary*)scores;
@end


@interface SocialScoresManager : NSObject
{
    UIWindow * window;
    ScoresViewController * scoresController;
}

+(id) sharedManager;
+ (BOOL)connected;

-(void)showTopScoresForLevel:(NSString*)levelId withOptions:(NSDictionary*)options;
-(void)loadTopScoresForLevel:(NSString*)levelId withOptions:(NSDictionary*)options;
-(BOOL)saveScore:(int)score forLevel:(NSString*)levelId;
-(void) setEnabled:(BOOL)isEnabled;
-(BOOL) isEnabled;
-(void)prepareForFbUser;

@property(nonatomic,retain) ScoresViewController * scoresController;

@end



