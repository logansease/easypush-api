//
//  SocialScoresManager.h
//
//  Created by logan sease on 12-05-01.
//  Copyright (c) 2012 Logan Sease. All rights reserved.
//  This is the manager for the social scores.

#import <UIKit/UIKit.h>
#import "ScoresViewController.h"
#import "SocialScoresConfig.h"

@protocol SocialScoresManagerDelegate <NSObject>
@optional
-(void)scoreLoadDidFinish:(NSDictionary*)scores;
@end


@interface SocialScoresManager : NSObject
{
    ScoresViewController * scoresController;
    UIView * loadingView;
    BOOL cancelled;
    BOOL disableSave;
}

-(void)stopLoading;
-(void) setupLoadingViewInView:(UIView*)view;
+(id) sharedManager;
+ (BOOL)connected;

-(void)showTopScoresForLevel:(NSString*)levelId inViewController:(UIViewController*)viewController withOptions:(NSDictionary*)options;
-(void)loadTopScoresForLevel:(NSString*)levelId withOptions:(NSDictionary*)options;
-(BOOL)saveScore:(int)score forLevel:(NSString*)levelId;
-(void) setEnabled:(BOOL)isEnabled;
-(BOOL) isEnabled;
-(void)prepareForFbUser;
@property(nonatomic,retain)  UIView * loadingView;
@property(nonatomic,retain) ScoresViewController * scoresController;
@property BOOL disableSave;

@end



