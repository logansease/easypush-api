//
//  SocialScoresConfig.m
//
//  Created by lsease on 7/26/12.
//

//TODO edit these config variables


//facebook app config
NSString *const kAppId = @"fb app id";
NSString *const kAppSecret = @"fb secret";

//social scores config
NSString *const  kSocialAppId  =            @"app id";
NSString *const  kSocialAppSecret    =      @"app secret";

//the variables define the popups and the sharing scores view
NSString *const kPostLink  =                 @"http://ipartymobile.com";
NSString *const  kPostImage  =              @"http://logansease.com/icon.png";
NSString *const  kAppName   =                 @"Social Scores!";
NSString *const  kLoadingText =   @"Loading Social Scoreboard";
