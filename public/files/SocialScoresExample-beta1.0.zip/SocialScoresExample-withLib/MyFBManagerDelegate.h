//
//  MyFBManagerDelegate.h
//  MovieQuotes
//
//  Created by lsease on 10-06-18.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//


#import "FBDialog.h"
@protocol MyFBManagerDelegate<NSObject,NSCoding>

@optional
-(void) gotFriendResults:(NSArray*)friends;
-(void) didFinishLogin;
-(void) didFinishLogout;
-(void) dialogDidSucceed:(FBDialog*)dialog;
@end
