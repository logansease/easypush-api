//
//  MyFBManager.h
//  MovieQuotes
//
//  Created by lsease on 10-06-16.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Facebook.h"
#import "MyFacebook.h"
#import "MyFBManagerDelegate.h"

//TODO edit these values for your facebook app
#define kAppId              @"app id"
#define kAppSecret			@"appsecret"

@interface MyFBManager : NSObject<FBSessionDelegate,FBDialogDelegate,FBRequestDelegate,UIWebViewDelegate> {
    
    //the facebook object for direct use
	Facebook * facebook;
    
    //a delegate to use for event callbacks
	id<MyFBManagerDelegate> delegate;
    
    //used internally to track the what dialog is being shown
	int dialogState;

    //email address of logged in user
    NSString * email;
    
    //name of logged in user
    NSString * name;
    
    //facebook id of logged in user
    int facebookId;

}

+ (id)sharedManager;
-(void)getFriendList;
-(void) showLogin;
-(void) postStoryWithAttachment:(NSMutableDictionary*)params toFriend:(NSString*)friendId;
-(void) autoPostStoryWithAttachment:(NSMutableDictionary*)params toFriend:(NSString*)friendId;

@property(nonatomic,retain) NSString * email;
@property(nonatomic,retain) NSString * name;
@property int facebookId;
@property(nonatomic,retain) id<MyFBManagerDelegate> delegate;
@property(nonatomic,retain) Facebook* facebook;

@end
